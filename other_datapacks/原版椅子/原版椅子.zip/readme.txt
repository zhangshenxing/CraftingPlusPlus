站在台阶或楼梯上时输入 /trigger chair 即可将该方块“转化”为椅子，空手右击即可坐上。
坐着的时候输入 /trigger chair 即可清除所坐的椅子。

玩家可以输入 /trigger chairMode 来开启胡萝卜钓竿模式，输入 /trigger chairMode set 0 来关闭。
该模式下玩家手持胡萝卜钓竿右击相当于执行了命令 /trigger chair。

直接拆除“椅子方块”也可移除椅子。

附加提醒：
- 两种椅子坐下的位置不同，台阶椅子在正中央，楼梯椅子则靠前。
- 若目标处已有椅子，则不会重复生成椅子。
- 楼梯转化而来的椅子朝向和楼梯一致，台阶转化而来的椅子朝向和生成时玩家的朝向相反。
- 当（楼梯“转化”成的）椅子面东或面南时，若椅子前紧邻不透明方块，从椅子上下来可能会导致窒息伤害。在椅子两侧添加活板门可避免发生此类情况。
- 椅子保质期为 3.4 年，过期后椅子会变异成羊驼。

Stand on a slab or a stair, use command /trigger chair to "transform" the block into a chair. 
Right-click with bare hands to sit on it.
When sitting in a chair, use command /trigger chair to remove it.

Use command /trigger chairMode to enable Carrot on a Stick mode, use command /trigger chairMode set 0 to disable this mode.
In this mode, using a Carrot on a Stick is the same the command /trigger chair.

Mining the "chair block" directly can also remove the chair.

Notifications:
- As for the position of sitting, slab chair is in the center, stair chair is near the front.
- If there is already a chair in the target, the block cannot be transformed any more.
- The facing of the chair coincides the facing of the stair. For slab, the facing is opposite to player.
- When the chair (transformed from a stair) is facing south or east, and there is a opaque block right in front of it, then getting off the chair may cause suffocoating damage. Attach trapdoors beside the chair block can prevent this.
- The expiration date on each chair is 3.4 years, after that the chair will degrade to a llama.
